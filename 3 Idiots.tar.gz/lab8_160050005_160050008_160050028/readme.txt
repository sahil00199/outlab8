CONTRIBUTION:
Everyone has given equal contribution in every problem:
Problem 1: 160050005, 160050008, 160050028
Problem 2: 160050005, 160050008, 160050028
Problem 3: 160050005, 160050008, 160050028
Problem 4: 160050005, 160050008, 160050028
Bonus Problem: 160050005, 160050008, 160050028

CITATIONS:
1. https://stackoverflow.com/questions/36484184/python-make-a-post-request-using-python-3-urllib - to find out how to send post requests using urllib
2. https://stackoverflow.com/questions/802134/changing-user-agent-on-urllib2-urlopen - to learn about the User-Agent HTTP header in urrlib and that used by the browser
3. http://academic.mu.edu/phys/matthysd/web226/Lab01.htm
